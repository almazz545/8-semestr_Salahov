import { FullOffer } from "../types/offer";

const offers: FullOffer[] = [
    {
        'id': 'a1',
        'title': 'Stylish Private Room Near Amsterdams Attractions',
        'description': 'A new spacious villa, one floor. All commodities, jacuzzi and beautiful scenery. Ideal for families',
        'type': 'private room',
        'price': 370,
        'images': [
            '../../img/ap1.jpg',
            '../../img/41.jpg',
            '../../img/42.jpg',
            '../../img/43.jpg',
            '../../img/44.jpg',
            '../../img/45.jpg'
        ],
        'city': {
        'name': 'Amsterdam',
        'location': {
            'latitude': 52.3676,
            'longitude': 4.9041,
            'zoom': 13
            }
        },
        'location': {
            'latitude': 52.370216,
            'longitude': 4.895168,
            'zoom': 16
        },
        'goods': [
            'Heating',
            'Wi-Fi',
            'Fridge',
            'Laptop friendly workspace',
            'Baby seat',
            'Air conditioning',
            'Washer',
            'Towels',
            'Dishwasher',
            'Kitchen',
            'Washing machine',
            'Breakfast',
            'Coffee machine'
        ],
        'host': {
            'isPro': true,
            'name': 'Angelina',
            'avatarUrl': 'avatar-angelina.jpg'
        },
        'isPremium': false,
        'isFavorite': true,
        'rating': 4.3,
        'bedrooms': 2,
        'maxAdults': 3
    },
    {
        'id': 'a2',
        'title': 'Cozy flat near the central station',
        'description': 'A new spacious villa, one floor. All commodities, jacuzzi and beautiful scenery. Ideal for families',
        'type': 'apartment',
        'price': 120,
        'images': [
            '../../img/ap2.jpg',
            '../../img/31.jpg',
            '../../img/32.jpg',
            '../../img/33.jpg',
            '../../img/34.jpg',
            '../../img/35.jpg'
        ],
        'city': {
            'name': 'Cologne',
            'location': {
                'latitude': 50.9375,
                'longitude': 6.9603,
                'zoom': 13
            }
        },
        'location': {
            'latitude': 50.9413,
            'longitude': 6.9583,
            'zoom': 16
        },
        'goods': [
            'Heating',
            'Wi-Fi',
            'Fridge',
            'Air conditioning',
            'Washer',
            'Towels',
            'Kitchen',
            'Coffee machine',
            'Smart TV',
            'Hairdryer',
            'Iron'
        ],
        'host': {
            'isPro': true,
            'name': 'Angelina',
            'avatarUrl': 'avatar-angelina.jpg'
        },
        'isPremium': false,
        'isFavorite': true,
        'rating': 4.9,
        'bedrooms': 1,
        'maxAdults': 3
    },
    {
        'id': 'a3',
        'title': 'Modern loft in the heart of Hamburg',
        'description': 'A stylish loft with an open floor plan, featuring large windows and contemporary decor. Perfect for urban explorers and business travelers',
        'type': 'apartment',
        'price': 250,
        'images': [
            '../../img/ap3.jpg',
            '../../img/21.jpg',
            '../../img/22.jpg',
            '../../img/23.jpg',
            '../../img/24.jpg',
            '../../img/25.jpg'
        ],
        'city': {
            'name': 'Hamburg',
            'location': {
                'latitude': 53.5753,
                'longitude': 10.0153,
                'zoom': 13
            }
        },
        'location': {
            'latitude': 53.57610000000004,
            'longitude': 10.019342499,
            'zoom': 16
        },
        'goods': [
            'Heating',
            'Wi-Fi',
            'Fridge',
            'Air conditioning',
            'Washer',
            'Towels',
            'Kitchen',
            'Coffee machine',
            'Smart TV',
            'Balcony'
        ],
        'host': {
            'isPro': true,
            'name': 'Angelina',
            'avatarUrl': 'avatar-angelina.jpg'
        },
        'isPremium': false,
        'isFavorite': true,
        'rating': 4.9,
        'bedrooms': 2,
        'maxAdults': 3
    },
    {
        'id': 'a4',
        'title': 'Modern apartment with city view',
        'description': 'A cozy apartment in the heart of Brussels, featuring modern amenities and a lovely balcony with city views. Perfect for couples or solo travelers',
        'type': 'apartment',
        'price': 450,
        'images': [
            '../../img/ap4.jpg',
            '../../img/XXXL (1).jpg',
            '../../img/XXXL (2).jpg',
            '../../img/XXXL (3).jpg',
            '../../img/XXXL (4).jpg',
            '../../img/XXXL (5).jpg'
        ],
        'city': {
            'name': 'Brussels',
            'location': {
                'latitude': 50.8503,
                'longitude': 4.34878,
                'zoom': 13
            }
        },
        'location': {
            'latitude': 50.8550,
            'longitude': 4.3501,
            'zoom': 16
        },
        'goods': [
            'Heating',
            'Wi-Fi',
            'Fridge',
            'Air conditioning',
            'Washer',
            'Towels',
            'Kitchen',
            'Coffee machine',
            'Smart TV',
            'Hairdryer'
        ],
        'host': {
            'isPro': true,
            'name': 'Angelina',
            'avatarUrl': 'avatar-angelina.jpg'
        },
        'isPremium': true,
        'isFavorite': true,
        'rating': 4.8,
        'bedrooms': 1,
        'maxAdults': 2
    }
]

export { offers };