import React from "react";
import { Review } from "../../types/review";

type ReviewItemProps = {
  review: Review;
};

function ReviewItem({ review }: ReviewItemProps): React.JSX.Element {
  const reviewDate = new Date(review.date).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  return (
    <li className="reviews__item">
      <div className="reviews__user user">
        <div className="reviews__avatar-wrapper user__avatar-wrapper">
          <img
            className="reviews__avatar user__avatar"
            src={review.user.avatarUrl}
            alt={`${review.user.name}'s avatar`}
            width="54"
            height="54"
          />
        </div>
        <span className="reviews__user-name">{review.user.name}</span>
        {review.user.isPro && <span className="reviews__user-status">Pro</span>}
      </div>
      <div className="reviews__info">
        <div className="reviews__rating rating">
          <div className="rating__stars">
            <span style={{ width: `${review.rating * 20}%` }}></span>
            <span className="visually-hidden">Rating</span>
          </div>
        </div>
        <p className="reviews__text">{review.comment}</p>
        <time className="reviews__time" dateTime={review.date}>
          {reviewDate}
        </time>
      </div>
    </li>
  );
}

export default ReviewItem;
