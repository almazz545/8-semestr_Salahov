import React from "react";
import { useAppDispatch, useAppSelector } from "../../hooks";
import { changeCity } from "../../store/actions";
import { CITIES_LOCATION } from "../../const";

export function Cities(): React.JSX.Element {
  const dispatch = useAppDispatch();
  const currentCity = useAppSelector((state) => state.city);

  const handleCityChange = (cityName: string) => {
    dispatch(changeCity(cityName));
  };

  return (
    <ul className="locations__list tabs__list">
      {CITIES_LOCATION.map((city) => (
        <li key={city.name} className="locations__item">
          <a
            className={`locations__item-link tabs__item ${
              currentCity === city.name ? "tabs__item--active" : ""
            }`}
            onClick={() => handleCityChange(city.name)}
            href="#"
          >
            <span>{city.name}</span>
          </a>
        </li>
      ))}
    </ul>
  );
}
