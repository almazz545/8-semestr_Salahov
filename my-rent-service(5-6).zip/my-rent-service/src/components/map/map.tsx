import React, { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import icon from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";
import { FullOffer } from "../../types/offer";
import { CITIES_LOCATION } from "../../const";

const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

type MapProps = {
  offers: FullOffer[];
  city: string;
};

const MapView = ({ city, offers }: MapProps) => {
  const map = useMap();
  const cityCoords =
    CITIES_LOCATION.find((c) => c.name === city) || CITIES_LOCATION[0];

  useEffect(() => {
    if (cityCoords) {
      map.setView(
        [cityCoords.location.latitude, cityCoords.location.longitude],
        cityCoords.location.zoom
      );
    }
  }, [city, cityCoords, map]);

  return (
    <>
      {offers.map((offer) => (
        <Marker
          key={offer.id}
          position={[offer.location.latitude, offer.location.longitude]}
        >
          <Popup>{offer.title}</Popup>
        </Marker>
      ))}
    </>
  );
};

const Map = React.memo(({ offers, city }: MapProps): React.JSX.Element => {
  const cityCoords =
    CITIES_LOCATION.find((c) => c.name === city) || CITIES_LOCATION[0];

  return (
    <MapContainer
      center={[cityCoords.location.latitude, cityCoords.location.longitude]}
      zoom={cityCoords.location.zoom}
      scrollWheelZoom={false}
      style={{ height: "400px", width: "100%" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <MapView city={city} offers={offers} />
      {offers.length === 0 && (
        <div
          style={{
            position: "absolute",
            top: "10px",
            left: "10px",
            zIndex: 1000,
          }}
        >
          No offers available in {city}
        </div>
      )}
    </MapContainer>
  );
});

export default Map;
