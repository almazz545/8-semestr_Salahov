import { JSX } from "react";
import { useSelector } from "react-redux";
import MainPage from "../../pages/main-page/main-page";
import Favorites from "../../pages/favorites/favorites";
import Login from "../../pages/login/login";
import Offer from "../../pages/offer/offer";
import NotFound from "../../pages/not-found/not-found";
import { PrivateRoute } from "../private-route/private-route";
import { AppRoute } from "../../const";
import { FullOffer } from "../../types/offer";
import { State } from "../../store";
import { BrowserRouter } from "react-router-dom";
import { Route } from "react-router";
import { Routes } from "react-router";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

type AppMainPageProps = {
  rentalOffersCount: number;
  offers: FullOffer[];
};

function App({ rentalOffersCount, offers }: AppMainPageProps): JSX.Element {
  const { authorizationStatus } = useSelector((state: State) => state.auth);

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path={AppRoute.Main}
          element={<MainPage rentalOffersCount={rentalOffersCount} />}
        />
        <Route
          path={AppRoute.Favorites}
          element={
            <PrivateRoute>
              <Favorites offers={offers} />
            </PrivateRoute>
          }
        />
        <Route path={AppRoute.Login} element={<Login />} />
        <Route
          path={`${AppRoute.Offer}/:id`}
          element={<Offer offers={offers} />}
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
