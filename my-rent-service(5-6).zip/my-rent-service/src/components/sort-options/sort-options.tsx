import React, { useState } from "react";
import { SortOffersType } from "../../const";
import { useAppDispatch, useAppSelector } from "../../hooks";
import { changeSortType } from "../../store/actions";

function SortOptions() {
  const [isOpen, setIsOpen] = useState(false);
  const currentSortType = useAppSelector((state) => state.sortType);
  const dispatch = useAppDispatch();

  const handleSortTypeChange = (sortType: string) => {
    dispatch(changeSortType(sortType));
    setIsOpen(false);
  };

  return (
    <form className="places__sorting" action="#" method="get">
      <span className="places__sorting-caption">Sort by</span>
      <span
        className="places__sorting-type"
        tabIndex={0}
        onClick={() => setIsOpen(!isOpen)}
      >
        {currentSortType}
        <svg className="places__sorting-arrow" width="7" height="4">
          <use href="#icon-arrow-select"></use>
        </svg>
      </span>
      {isOpen && (
        <ul className="places__options places__options--custom places__options--opened">
          {Object.values(SortOffersType).map((sortType) => (
            <li
              key={sortType}
              className={`places__option ${
                currentSortType === sortType ? "places__option--active" : ""
              }`}
              tabIndex={0}
              onClick={() => handleSortTypeChange(sortType)}
            >
              {sortType}
            </li>
          ))}
        </ul>
      )}
    </form>
  );
}

export default SortOptions;
