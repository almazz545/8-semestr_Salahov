import { Navigate } from "react-router-dom";
import { PropsWithChildren } from "react";
import { useSelector } from "react-redux";
import { AppRoute, AuthorizationStatus } from "../../const";
import { State } from "../../store";

function PrivateRoute(props: PropsWithChildren) {
  const { authorizationStatus } = useSelector((state: State) => state.auth);
  const { children } = props;

  return authorizationStatus === AuthorizationStatus.Auth ? (
    <>{children}</>
  ) : (
    <Navigate to={AppRoute.Login} replace />
  );
}

export { PrivateRoute };
