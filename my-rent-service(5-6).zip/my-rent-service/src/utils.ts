import { CityOffer } from "./types/state";
import { OffersList } from "./types/offer";
import { CITIES_LOCATION } from "./const";
import { SortType } from "./types/sort";

export const getCity = (
  cityName: string,
  cities: CityOffer[] = CITIES_LOCATION
): CityOffer | undefined => {
  return cities.find((city) => city.name === cityName);
};

export const sortOffers = (
  offers: OffersList[],
  sortType: SortType
): OffersList[] => {
  switch (sortType) {
    case "Price: low to high":
      return [...offers].sort((a, b) => a.price - b.price);

    case "Price: high to low":
      return [...offers].sort((a, b) => b.price - a.price);

    case "Top rated first":
      return [...offers].sort((a, b) => b.rating - a.rating);

    default:
      return offers;
  }
};
