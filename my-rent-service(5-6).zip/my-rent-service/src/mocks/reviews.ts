import { Review } from "../types/review";

export const reviews: Review[] = [
  {
    id: "1",
    user: {
      name: "Max",
      avatarUrl: "https://url-to-avatar.com/max.jpg",
      isPro: false,
    },
    comment: "Cozy apartment with nice view. Recommend for solo travelers.",
    date: "2024-03-15",
    rating: 4,
  },
  {
    id: "2",
    user: {
      name: "Emma",
      avatarUrl: "https://url-to-avatar.com/emma.jpg",
      isPro: true,
    },
    comment: "Great location, clean and comfortable. Enjoyed my stay!",
    date: "2024-03-10",
    rating: 5,
  },
  {
    id: "3",
    user: {
      name: "John",
      avatarUrl: "https://url-to-avatar.com/john.jpg",
      isPro: false,
    },
    comment: "Decent place, but could use some improvements.",
    date: "2024-02-25",
    rating: 3,
  },
];
