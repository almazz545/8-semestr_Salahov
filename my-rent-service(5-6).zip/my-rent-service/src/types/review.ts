export interface Review {
  id: string;
  user: {
    name: string;
    avatarUrl: string;
    isPro: boolean;
  };
  comment: string;
  date: string;
  rating: number;
}
