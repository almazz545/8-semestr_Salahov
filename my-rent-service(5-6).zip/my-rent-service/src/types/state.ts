import { OffersList } from "./offer";
import { SortOffersType } from "../const";

export type Location = {
  latitude: number;
  longitude: number;
  zoom: number;
};

export type CityOffer = {
  name: string;
  location: Location;
};

export type State = {
  city: string;
  offers: OffersList[];
  sortType: (typeof SortOffersType)[keyof typeof SortOffersType];
};

export type ActionType =
  | { type: "CHANGE_CITY"; payload: string }
  | { type: "SET_OFFERS"; payload: OffersList[] }
  | {
      type: "CHANGE_SORT";
      payload: (typeof SortOffersType)[keyof typeof SortOffersType];
    };
