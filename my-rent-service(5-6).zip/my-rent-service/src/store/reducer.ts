import { createReducer } from "@reduxjs/toolkit";
import { changeCity, setOffers, changeSortType } from "./actions";
import { State } from "../types/state";
import { offersList } from "../mocks/offers-list";
import { SortOffersType } from "../const";

const initialState: State = {
  city: "Paris",
  offers: offersList,
  sortType: SortOffersType.Popular,
};

export const reducer = createReducer(initialState, (builder) => {
  builder
    .addCase(changeCity, (state, action) => {
      state.city = action.payload;
    })
    .addCase(setOffers, (state, action) => {
      state.offers = action.payload;
    })
    .addCase(changeSortType, (state, action) => {
      state.sortType = action.payload;
    });
});
