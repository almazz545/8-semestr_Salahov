import { createAction } from "@reduxjs/toolkit";
import { OffersList } from "../types/offer";
import { SortType } from "../types/sort";

export const changeCity = createAction<string>("CHANGE_CITY");
export const setOffers = createAction<OffersList[]>("SET_OFFERS");
export const changeSortType = createAction<SortType>("CHANGE_SORT");
