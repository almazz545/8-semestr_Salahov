import { configureStore } from "@reduxjs/toolkit";
import { reducer as mainReducer } from "./reducer";
import authReducer from "./auth-slice";

export const store = configureStore({
  reducer: {
    main: mainReducer,
    auth: authReducer,
  },
});

export type State = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
