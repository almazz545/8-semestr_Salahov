import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { AuthorizationStatus } from "../const";

type AuthState = {
  authorizationStatus: string;
  email: string | null;
};

const initialState: AuthState = {
  authorizationStatus: AuthorizationStatus.NoAuth,
  email: null,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login: (state, action: PayloadAction<string>) => {
      state.authorizationStatus = AuthorizationStatus.Auth;
      state.email = action.payload;
    },
    logout: (state) => {
      state.authorizationStatus = AuthorizationStatus.NoAuth;
      state.email = null;
    },
  },
});

export const { login, logout } = authSlice.actions;
export default authSlice.reducer;
